http istio.demo/v1/istiodemowrapper;
fortio load -quiet -c 5 -qps 0 -n 50 -timeout 8000ms -k http://istio.demo/v1/istiodemowrapper;