kind create cluster --name=mgmt;
kind create cluster --name=airtel-1;
kind create cluster --name=airtel-2;

kubectl apply -f config/metallb-ns.yaml --context=kind-mgmt;
kubectl apply -f config/metallb-ns.yaml --context=kind-airtel-1;
kubectl apply -f config/metallb-ns.yaml --context=kind-airtel-2;

kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-mgmt;
kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-airtel-1;
kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-airtel-2;

kubectl apply -f config/metallb.yaml --context=kind-mgmt;
kubectl apply -f config/metallb.yaml --context=kind-airtel-1;
kubectl apply -f config/metallb.yaml --context=kind-airtel-2;


kubectl apply -f config/metallb-mgmt.yaml --context=kind-mgmt;
kubectl apply -f config/metallb-airtel-1.yaml --context=kind-airtel-1;
kubectl apply -f config/metallb-airtel-2.yaml --context=kind-airtel-2;

