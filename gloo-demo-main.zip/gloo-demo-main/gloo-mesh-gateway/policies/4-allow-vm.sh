kubectl --context kind-airtel-1 apply -f ../config/authz-vm.yaml;

