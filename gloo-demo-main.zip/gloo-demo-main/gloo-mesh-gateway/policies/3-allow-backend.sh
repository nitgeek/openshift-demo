cat << EOF | kubectl --context kind-mgmt apply -f -
apiVersion: networking.mesh.gloo.solo.io/v1
kind: AccessPolicy
metadata:
  namespace: gloo-mesh
  name: backend
spec:
  sourceSelector:
  - kubeServiceAccountRefs:
      serviceAccounts:
        - name: default
          namespace: default
          clusterName: kind-airtel-1
        - name: istio-ingressgateway-service-account
          namespace: istio-system
          clusterName: kind-airtel-1
        - name: istio-ingressgateway-service-account
          namespace: istio-system
          clusterName: kind-airtel-2 
        - name: vm-1
          namespace: vm-1
          clusterName: kind-airtel-1                   
  destinationSelector:
  - kubeServiceRefs:
      services:
      - name: istio-demo
        namespace: vm-1
        clusterName: kind-airtel-1
  - kubeServiceMatcher:
      namespaces:
      - default
      labels:
        app: istio-demo-v1-1 
      clusters:
      - kind-airtel-2        
EOF
