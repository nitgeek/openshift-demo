cat << EOF | kubectl --context kind-mgmt apply -f -
apiVersion: networking.mesh.gloo.solo.io/v1
kind: AccessPolicy
metadata:
  namespace: gloo-mesh
  name: istio-ingressgateway
spec:
  sourceSelector:
  - kubeServiceAccountRefs:
      serviceAccounts:
        - name: istio-ingressgateway-service-account
          namespace: istio-system
          clusterName: kind-airtel-1
        - name: istio-ingressgateway-service-account
          namespace: istio-system
          clusterName: kind-airtel-2
          
  destinationSelector:
  - kubeServiceMatcher:
      namespaces:
      - default
      labels:
        app: istio-demo-wrapper
EOF