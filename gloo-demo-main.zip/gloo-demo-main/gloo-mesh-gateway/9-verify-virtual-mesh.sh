kubectl get virtualmesh -n gloo-mesh virtual-mesh -oyaml --context kind-mgmt;
