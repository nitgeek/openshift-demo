cat << EOF | kubectl apply --context kind-mgmt -f -
---
apiVersion: discovery.mesh.gloo.solo.io/v1
kind: Workload
metadata:
  name: istio-demo-vm-1-kind-airtel-1
  namespace: gloo-mesh
spec:
  kubernetes:
    controller:
      clusterName: kind-airtel-1
      name: istio-demo
      namespace: vm-1
    podLabels:
      app: istio-demo
    serviceAccountName: vm-1
  mesh:
    name: istiod-istio-system-kind-airtel-1
    namespace: gloo-mesh
---
apiVersion: discovery.mesh.gloo.solo.io/v1
kind: Destination
metadata:
  name: istio-demo-vm-1-kind-airtel-1
  namespace: gloo-mesh
spec:
  kubeService:
    labels:
      app: istio-demo
    ref:
      clusterName: kind-airtel-1
      name: istio-demo-vm-1
      namespace: vm-1
    workloadSelectorLabels:
      app: istio-demo
  mesh:
    name: istiod-istio-system-kind-airtel-1
    namespace: gloo-mesh
EOF
