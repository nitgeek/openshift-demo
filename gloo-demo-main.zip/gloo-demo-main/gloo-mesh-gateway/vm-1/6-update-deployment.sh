kubectl get cm spring-boot-configmaps --context kind-airtel-1 -o yaml;
kubectl delete cm spring-boot-configmaps --context kind-airtel-1;
kubectl create cm spring-boot-configmaps --from-literal hostv1=istio-demo-v1-1.default.svc.kind-airtel-2.global --from-literal hostv2=istio-demo.vm-1 --context kind-airtel-1;
kubectl scale --replicas=0 deployment/istio-demo-wrapper  --context kind-airtel-1;
kubectl scale --replicas=1 deployment/istio-demo-wrapper  --context kind-airtel-1;