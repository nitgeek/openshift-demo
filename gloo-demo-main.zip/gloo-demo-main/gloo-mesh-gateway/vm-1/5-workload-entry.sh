cat << EOF | kubectl apply --context kind-airtel-1 -f -
# Please edit the object below. Lines beginning with a '#' will be ignored,
# and an empty file will abort the edit. If an error occurs while saving this file will be
# reopened with the relevant failures.
#
apiVersion: networking.istio.io/v1beta1
kind: WorkloadEntry
metadata:
  labels:
    app: istio-demo
    service.istio.io/canonical-name: istio-demo
    service.istio.io/canonical-version: latest
  name: istio-demo-172.28.128.18-network1
  namespace: vm-1
spec:
  address: 172.28.128.18
  labels:
    app: istio-demo
    service.istio.io/canonical-name: istio-demo
    service.istio.io/canonical-version: latest
  network: network1
  serviceAccount: vm-1
EOF
