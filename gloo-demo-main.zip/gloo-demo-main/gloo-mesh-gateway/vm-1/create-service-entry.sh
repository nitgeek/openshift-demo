cat << EOF | kubectl apply --context kind-airtel-1 -f -
apiVersion: networking.istio.io/v1alpha3
kind: ServiceEntry
metadata:
  name: vm-istio-demo
  namespace: istio-system
spec:
  hosts:
  - vm.istiodemo
  exportTo:
  - "*"
  location: MESH_INTERNAL
  ports: 
  - number: 8080
    name: http
    protocol: HTTP       
  resolution: STATIC
  endpoints:
  - address: 172.28.128.18 
EOF
