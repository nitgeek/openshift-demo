cat << EOF | kubectl apply --context kind-mgmt -f -
apiVersion: networking.enterprise.mesh.gloo.solo.io/v1beta1
kind: VirtualGateway
metadata:
  name: demo-gateway
  namespace: gloo-mesh
spec:
  ingressGatewaySelectors:
  - portName: http2
    destinationSelectors:
    - kubeServiceMatcher:
        clusters:
        - kind-airtel-1
        labels:
          istio: ingressgateway
        namespaces:
        - istio-system
  connectionHandlers:
  - http:
      routeConfig:
      - virtualHost:
          domains:
          - istio.demo
          routes:
          - matchers:
            - uri:
                prefix: /v1/istiodemowrapper
            name: istiodemowrapper
            routeAction:
              destinations:
              - kubeService:
                  clusterName: kind-airtel-1
                  name: istio-demo-wrapper
                  namespace: default
                  port: 8080
EOF
