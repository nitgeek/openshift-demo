cat << EOF | kubectl apply --context kind-airtel-1 -f -
apiVersion: v1
kind: Service
metadata:
  labels:
    app: istio-demo
  name: istio-demo-vm-1
  namespace: vm-1
spec:
  ports:
  - name: http
    port: 8080
    protocol: TCP
    targetPort: 8080
  selector:
    app: istio-demo
  type: ClusterIP
EOF
