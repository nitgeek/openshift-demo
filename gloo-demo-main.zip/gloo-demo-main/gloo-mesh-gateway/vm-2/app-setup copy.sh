sudo apt-get update;
sudo apt install nodejs -y;
sudo apt install npm -y;
cd /vagrant/openshift-demo;
npm install;
node app.js;


