VM_APP="istio-demo";
VM_NAMESPACE="vm-1";
WORK_DIR="istio-setup";
SERVICE_ACCOUNT="vm-1";
CLUSTER_NETWORK="network1";
VM_NETWORK="eth1";
CLUSTER="kind-airtel-1";

kubectl config use-context kind-airtel-1;
istioctl install -y -f config/east-west-gw.yaml;
kubectl apply -f config/istiod-routes.yaml;
kubectl create namespace "${VM_NAMESPACE}";
kubectl create serviceaccount "${SERVICE_ACCOUNT}" -n "${VM_NAMESPACE}";
cat << EOF | kubectl apply --context kind-airtel-1 -f -
apiVersion: networking.istio.io/v1alpha3
kind: WorkloadGroup
metadata:
  name: "${VM_APP}"
  namespace: "${VM_NAMESPACE}"
spec:
  metadata:
    labels:
      app: "${VM_APP}"
  template:
    serviceAccount: "${SERVICE_ACCOUNT}"
    network: "${VM_NETWORK}"
EOF


istioctl x workload entry configure -f workloadgroup.yaml -o "${WORK_DIR}" --clusterID "${CLUSTER}" --autoregister;





