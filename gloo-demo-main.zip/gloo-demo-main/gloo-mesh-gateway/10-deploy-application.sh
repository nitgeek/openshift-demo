kubectl label namespace default istio-injection=enabled --overwrite --context kind-airtel-1;
kubectl label namespace default istio-injection=enabled --overwrite --context kind-airtel-2;
kubectl apply -f config/deploy-service-v1.0.yaml --context kind-airtel-1;
kubectl apply -f config/deploy-service-v1.1.yaml --context kind-airtel-2;
kubectl apply -f config/wrapper-deploy.yaml --context kind-airtel-1;