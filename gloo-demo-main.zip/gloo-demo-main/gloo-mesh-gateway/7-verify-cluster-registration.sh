kubectl get kubernetescluster -n gloo-mesh --context kind-mgmt;
kubectl get mesh -n gloo-mesh --context kind-mgmt;
