ENTERPRISE_NETWORKING_DOMAIN=$(kubectl get svc -n gloo-mesh enterprise-networking --context kind-mgmt -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
ENTERPRISE_NETWORKING_PORT=$(kubectl -n gloo-mesh get service enterprise-networking --context kind-mgmt -o jsonpath='{.spec.ports[?(@.name=="grpc")].port}')
ENTERPRISE_NETWORKING_ADDRESS=${ENTERPRISE_NETWORKING_DOMAIN}:${ENTERPRISE_NETWORKING_PORT}
echo $ENTERPRISE_NETWORKING_ADDRESS

meshctl cluster register enterprise \
  --mgmt-context=kind-mgmt \
  --remote-context=kind-airtel-1 \
  --relay-server-address $ENTERPRISE_NETWORKING_ADDRESS \
  kind-airtel-1;

meshctl cluster register enterprise \
  --mgmt-context=kind-mgmt \
  --remote-context=kind-airtel-2 \
  --relay-server-address $ENTERPRISE_NETWORKING_ADDRESS \
  kind-airtel-2;  


