meshctl check server --kubecontext kind-mgmt;

kubectl get po -n istio-system --context kind-airtel-1;
kubectl get po -n istio-system --context kind-airtel-2;
