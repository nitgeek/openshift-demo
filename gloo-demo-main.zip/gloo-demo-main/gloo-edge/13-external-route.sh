
kubectl apply -f config/external-federated-upstream.yaml --context kind-mgmt;
kubectl apply -f config/external-federated-vs.yaml --context kind-mgmt;
