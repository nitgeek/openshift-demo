kubectl apply -f config/virtual-service-airtel-1.yaml --context kind-airtel-1;
kubectl apply -f config/virtual-service-airtel-2.yaml --context kind-airtel-2;