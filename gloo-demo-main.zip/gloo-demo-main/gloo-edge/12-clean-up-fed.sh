kubectl delete -f config/federated-upstream.yaml --context kind-mgmt;
kubectl delete -f config/federated-vs.yaml --context kind-mgmt;