kind create cluster --name=mgmt;
kind create cluster --name=airtel-1;
kind create cluster --name=airtel-2;

kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/namespace.yaml --context=kind-mgmt;
kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/namespace.yaml --context=kind-airtel-1;
kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/namespace.yaml --context=kind-airtel-2;

kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-mgmt;
kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-airtel-1;
kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-airtel-2;

kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/metallb.yaml --context=kind-mgmt;
kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/metallb.yaml --context=kind-airtel-1;
kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/metallb.yaml --context=kind-airtel-2;


kubectl apply -f config/metallb-mgmt.yaml --context=kind-mgmt;
kubectl apply -f config/metallb-airtel-1.yaml --context=kind-airtel-1;
kubectl apply -f config/metallb-airtel-2.yaml --context=kind-airtel-2;

kubectl config use-context kind-mgmt;
$HOME/.gloo/bin/glooctl install gateway enterprise --license-key eyJleHAiOjE2NDE2MDAwMDAsImlhdCI6MTYzOTAwODAwMCwiayI6IjhtdW14QSIsImx0IjoidHJpYWwiLCJwcm9kdWN0IjoiZ2xvbyJ9.1er_vdOOrto28TKUrGT4v0hBCZEuQ1AYaFzmY8SnI2U;
kubectl config use-context kind-airtel-1;
$HOME/.gloo/bin/glooctl install gateway enterprise --license-key eyJleHAiOjE2NDE2MDAwMDAsImlhdCI6MTYzOTAwODAwMCwiayI6IjhtdW14QSIsImx0IjoidHJpYWwiLCJwcm9kdWN0IjoiZ2xvbyJ9.1er_vdOOrto28TKUrGT4v0hBCZEuQ1AYaFzmY8SnI2U;
kubectl config use-context kind-airtel-2;
$HOME/.gloo/bin/glooctl install gateway enterprise --license-key eyJleHAiOjE2NDE2MDAwMDAsImlhdCI6MTYzOTAwODAwMCwiayI6IjhtdW14QSIsImx0IjoidHJpYWwiLCJwcm9kdWN0IjoiZ2xvbyJ9.1er_vdOOrto28TKUrGT4v0hBCZEuQ1AYaFzmY8SnI2U;


