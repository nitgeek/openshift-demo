kubectl delete -f config/virtual-service-airtel-1.yaml --context kind-airtel-1;
kubectl delete -f config/virtual-service-airtel-2.yaml --context kind-airtel-2;
kubectl apply -f config/federated-upstream.yaml --context kind-mgmt;
kubectl apply -f config/federated-vs.yaml --context kind-mgmt;