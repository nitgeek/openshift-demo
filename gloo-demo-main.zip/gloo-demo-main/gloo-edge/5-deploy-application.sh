kubectl apply -f config/deploy-service-v1.0.yaml --context kind-airtel-1;
kubectl apply -f config/deploy-service-v1.1.yaml --context kind-airtel-2;