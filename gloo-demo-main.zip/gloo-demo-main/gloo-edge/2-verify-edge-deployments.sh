kubectl --namespace gloo-system get po --context kind-mgmt;
kubectl --namespace gloo-system get po --context kind-airtel-1;
kubectl --namespace gloo-system get po --context kind-airtel-2;