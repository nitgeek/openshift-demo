kubectl config use-context kind-mgmt;
echo "-----------Registering Clusters--------------------------------------"
$HOME/.gloo/bin/glooctl cluster register --cluster-name kind-mgmt --remote-context kind-mgmt --local-cluster-domain-override 172.18.0.2:6443;
$HOME/.gloo/bin/glooctl cluster register --cluster-name kind-airtel-2 --remote-context kind-airtel-2 --local-cluster-domain-override 172.18.0.4:6443;
$HOME/.gloo/bin/glooctl cluster register --cluster-name kind-airtel-1 --remote-context kind-airtel-1 --local-cluster-domain-override 172.18.0.3:6443;
echo "-----------verifying gloo instances on mgmt cluster-----------------"
kubectl get glooinstances -n gloo-system --context kind-mgmt;
