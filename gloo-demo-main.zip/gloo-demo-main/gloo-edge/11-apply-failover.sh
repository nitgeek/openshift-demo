
kubectl delete -f failover-scheme.yaml --context kind-mgmt;
kubectl delete secret failover-downstream -n gloo-system --context kind-airtel-2;
kubectl delete secret failover-upstream -n gloo-system --context kind-airtel-1;
k get svc -n gloo-system;
# Generate downstream cert and key
openssl req -x509 -nodes -days 365 -newkey rsa:2048   -keyout tls.key -out tls.crt -subj "/CN=solo.io";
openssl req -x509 -nodes -days 365 -newkey rsa:2048   -keyout mtls.key -out mtls.crt -subj "/CN=solo.io";

kubectl config use-context kind-airtel-1;
glooctl create secret tls --name failover-upstream --certchain mtls.crt --privatekey mtls.key;
kubectl config use-context kind-airtel-2;
glooctl create secret tls --name failover-downstream --certchain tls.crt --privatekey tls.key --rootca mtls.crt;
kubectl apply -f - <<EOF
apiVersion: gateway.solo.io/v1
kind: Gateway
metadata:
 name: failover-gateway
 namespace: gloo-system
 labels:
   app: gloo
spec:
 bindAddress: "::"
 bindPort: 15443
 tcpGateway:
   tcpHosts:
   - name: failover
     sslConfig:
       secretRef:
         name: failover-downstream
         namespace: gloo-system
     destination:
       forwardSniClusterName: {}

---
apiVersion: v1
kind: Service
metadata:
 labels:
   app: gloo
   gateway-proxy-id: gateway-proxy
   gloo: gateway-proxy
 name: failover
 namespace: gloo-system
spec:
 ports:
 - name: failover
   nodePort: 32000
   port: 15443
   protocol: TCP
   targetPort: 15443
 selector:
   gateway-proxy: live
   gateway-proxy-id: gateway-proxy
 sessionAffinity: None
 type: LoadBalancer
EOF

kubectl get gateway -n gloo-system failover-gateway;
kubectl get svc -n gloo-system failover;

kubectl patch --context kind-airtel-1 upstream -n gloo-system fed-upstream --type=merge -p "
spec:
 healthChecks:
 - timeout: 1s
   interval: 1s
   unhealthyThreshold: 1
   healthyThreshold: 1
   httpHealthCheck:
     path: /health
";
kubectl apply -f config/failover-scheme.yaml --context kind-mgmt;
kubectl get FailoverScheme failover-scheme -n gloo-system -o yaml --context kind-mgmt;