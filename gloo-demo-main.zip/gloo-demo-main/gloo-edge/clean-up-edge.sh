
kubectl config use-context kind-airtel-1;

glooctl uninstall --all;


kubectl config use-context kind-airtel-2;

glooctl uninstall --all;

kubectl config use-context kind-mgmt;

glooctl uninstall --all;


