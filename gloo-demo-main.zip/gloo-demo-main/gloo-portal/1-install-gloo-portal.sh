kubectl config use-context kind-mgmt;
# Add the Helm repository for Gloo Portal
helm repo add gloo-portal https://storage.googleapis.com/dev-portal-helm;
helm repo update;
# Create the namespace and install the Helm chart
kubectl create namespace gloo-portal;
helm install gloo-portal gloo-portal/gloo-portal -n gloo-portal --values gloo-values.yaml;