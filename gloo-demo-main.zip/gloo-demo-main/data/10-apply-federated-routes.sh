kubectl delete -f virtual-service-airtel-1.yaml --context kind-airtel-1;
kubectl delete -f virtual-service-airtel-2.yaml --context kind-airtel-2;
kubectl apply -f federated-upstream.yaml --context kind-mgmt;
kubectl apply -f federated-vs.yaml --context kind-mgmt;