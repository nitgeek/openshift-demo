kubectl apply -f vs-external.yaml --context kind-airtel-1;
kubectl apply -f virtual-service-airtel-2.yaml --context kind-airtel-2;