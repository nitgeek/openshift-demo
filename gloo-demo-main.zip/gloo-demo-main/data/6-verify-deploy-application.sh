kubectl get po --context kind-airtel-1;
kubectl get po --context kind-airtel-2;