# curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl";
# chmod +x ./kubectl;
# sudo mv ./kubectl /usr/local/bin/;

# curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.11.1/kind-linux-amd64;
# chmod +x ./kind;
# sudo mv ./kind /usr/local/bin/;


cat <<EOF | kind create cluster --name mgmt  --config=-
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 31500
    hostPort: 31500
    protocol: TCP
    listenAddress: "0.0.0.0"
  - containerPort: 32500
    hostPort: 32500
    protocol: TCP
    listenAddress: "0.0.0.0"
  - containerPort: 6443
    hostPort: 6443
    protocol: TCP
    listenAddress: "0.0.0.0"        
EOF


cat <<EOF | kind create cluster --name airtel-1  --config=-
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 31500
    hostPort: 31501
    protocol: TCP
    listenAddress: "0.0.0.0"
  - containerPort: 32500
    hostPort: 32501
    protocol: TCP
    listenAddress: "0.0.0.0"
  - containerPort: 6443
    hostPort: 6444
    protocol: TCP
    listenAddress: "0.0.0.0"        
EOF

cat <<EOF | kind create cluster --name airtel-2  --config=-
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 31500
    hostPort: 31502
    protocol: TCP
    listenAddress: "0.0.0.0"
  - containerPort: 32500
    hostPort: 32502
    protocol: TCP
    listenAddress: "0.0.0.0"
  - containerPort: 6443
    hostPort: 6445
    protocol: TCP
    listenAddress: "0.0.0.0"        
EOF
# kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/namespace.yaml --context=kind-mgmt;
# kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/namespace.yaml --context=kind-airtel-1;
# kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/namespace.yaml --context=kind-airtel-2;

# kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-mgmt;
# kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-airtel-1;
# kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)" --context=kind-airtel-2;

# kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/metallb.yaml --context=kind-mgmt;
# kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/metallb.yaml --context=kind-airtel-1;
# kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/master/manifests/metallb.yaml --context=kind-airtel-2;

# curl -sL https://run.solo.io/gloo/install | sh ;
# export PATH=$HOME/.gloo/bin:$PATH ;

kubectl config use-context kind-mgmt;
$HOME/.gloo/bin/glooctl install gateway enterprise --license-key eyJleHAiOjE2NDE2MDAwMDAsImlhdCI6MTYzOTAwODAwMCwiayI6IjhtdW14QSIsImx0IjoidHJpYWwiLCJwcm9kdWN0IjoiZ2xvbyJ9.1er_vdOOrto28TKUrGT4v0hBCZEuQ1AYaFzmY8SnI2U;
kubectl config use-context kind-airtel-1;
$HOME/.gloo/bin/glooctl install gateway enterprise --license-key eyJleHAiOjE2NDE2MDAwMDAsImlhdCI6MTYzOTAwODAwMCwiayI6IjhtdW14QSIsImx0IjoidHJpYWwiLCJwcm9kdWN0IjoiZ2xvbyJ9.1er_vdOOrto28TKUrGT4v0hBCZEuQ1AYaFzmY8SnI2U;
kubectl config use-context kind-airtel-2;
$HOME/.gloo/bin/glooctl install gateway enterprise --license-key eyJleHAiOjE2NDE2MDAwMDAsImlhdCI6MTYzOTAwODAwMCwiayI6IjhtdW14QSIsImx0IjoidHJpYWwiLCJwcm9kdWN0IjoiZ2xvbyJ9.1er_vdOOrto28TKUrGT4v0hBCZEuQ1AYaFzmY8SnI2U;
