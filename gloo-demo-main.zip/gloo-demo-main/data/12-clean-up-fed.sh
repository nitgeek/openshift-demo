kubectl delete -f federated-upstream.yaml --context kind-mgmt;
kubectl delete -f federated-vs.yaml --context kind-mgmt;