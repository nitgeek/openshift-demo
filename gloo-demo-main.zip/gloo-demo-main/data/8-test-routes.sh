kubectl config use-context kind-airtel-1;
echo "---------------------airtel-1--------------------"
http $(glooctl proxy url)/v1/istiodemo;

kubectl config use-context kind-airtel-2;
echo "---------------------airtel-2--------------------"
http $(glooctl proxy url)/v1/istiodemo;

