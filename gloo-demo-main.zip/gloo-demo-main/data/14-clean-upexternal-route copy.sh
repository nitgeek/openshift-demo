kubectl delete -f vs-external.yaml --context kind-airtel-1;
kubectl delete -f virtual-service-airtel-2.yaml --context kind-airtel-2;